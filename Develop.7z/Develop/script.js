// Assignment Code
var generateBtn = document.querySelector("#generate");

function writePassword() {
  var password = generatePassword();
  var passwordText = document.querySelector("#password");

  passwordText.value = password;
}

// // Add event listener to generate button
generateBtn.addEventListener("click", generatePassword()
);

function generatePassword() {
  var passwordLength = parseInt(prompt("How many characters in between 8 and 128?"));
  var upperCaseEnable = confirm("Do you want uppercase characters?");
  var lowerCaseEnable = confirm("Do you want lowercase characters?")
  var symbolsEnable = confirm("Do you want symbols?")
  var numbersEnable = confirm("Do you want numbers?")

  //conditional statement
  if (isNaN(passwordLength) === true) {
    alert("Must be a number");
    return;
  }
  else if (passwordLength === null) {
    return;
  }
  else if (passwordLength < 8) {
    alert("Length must be at least 8 characters");
  }
  else if (passwordLength > 128) {
    alert("Length must be no more than 128 characters");
  }
  else if (upperCaseEnable === false &&
    lowerCaseEnable === false &&
    symbolsEnable === false &&
    numbersEnable === false) {
    alert("You have to pick at least one option");
    return

    function randomElement(array) {
      var randomize = Math.floor(Math.random() * array.passwordLength);
      var rand = array[randomize];
      return rand
    }
  }
  // fromCharCode method seen on https://www.youtube.com/watch?v=duNmhKgtcsI&t=16s
  function randomUppercase() {
    return String.fromCharCode(Math.floor(Math.random() * 26) + 65)
  }
  function randomLowerCase() {
    return String.fromCharCode(Math.floor(Math.random() * 26) + 97)
  }
  function randomNumber() {
    return String.fromCharCode(Math.floor(Math.random() * 10) + 48)
  }
  function randomSymbol() {
    const symbol = '!@#$%^&*(){}[]=<>/,.'
    return symbol[Math.floor(Math.random() * symbol.length)];
  }
}